const GITHUB_USER = "Yrashka200";
const GITHUB_REPO = "youtube-fliter";
const GITHUB_BRANCH = "main";

const MANIFEST_URL = `https://raw.githubusercontent.com/${GITHUB_USER}/${GITHUB_REPO}/${GITHUB_BRANCH}/FireFox/manifest.json`;
const CHANGELOG_URL = `https://raw.githubusercontent.com/${GITHUB_USER}/${GITHUB_REPO}/${GITHUB_BRANCH}/CHANGELOG.md`;
const NOTIFICATIONS_URL = `https://raw.githubusercontent.com/${GITHUB_USER}/${GITHUB_REPO}/${GITHUB_BRANCH}/notifications.json`;

function isNewerVersion(remote, local) {
  const r = remote.split(".").map(n => parseInt(n, 10) || 0);
  const l = local.split(".").map(n => parseInt(n, 10) || 0);
  const len = Math.max(r.length, l.length);
  for (let i = 0; i < len; i++) {
    const rv = r[i] || 0;
    const lv = l[i] || 0;
    if (rv > lv) return true;
    if (rv < lv) return false;
  }
  return false;
}

function getLocalVersion() {
  return browser.runtime.getManifest().version;
}

function parseChangelog(md) {
  if (!md) return [];

  const lines = md.split(/\r?\n/);
  const entries = [];
  let current = null;

  for (const line of lines) {
    const versionMatch = line.match(/^##\s+\[?([0-9]+\.[0-9]+\.[0-9]+[^\]]*)\]?(?:\s*-\s*(.+))?/);
    if (versionMatch) {
      if (current) entries.push(current);
      current = {
        version: versionMatch[1].trim(),
        date: (versionMatch[2] || "").trim(),
        body: ""
      };
      continue;
    }

    if (!current) continue;
    if (/^#\s+Changelog/i.test(line)) continue;

    current.body += line + "\n";
  }

  if (current) entries.push(current);

  return entries.map(e => ({ ...e, body: e.body.trim() }));
}

async function fetchRemoteManifest() {
  const res = await fetch(MANIFEST_URL + "?t=" + Date.now(), { cache: "no-store" });
  if (!res.ok) throw new Error("Manifest fetch failed: " + res.status);
  return await res.json();
}

async function fetchChangelog() {
  const res = await fetch(CHANGELOG_URL + "?t=" + Date.now(), { cache: "no-store" });
  if (!res.ok) return "";
  return await res.text();
}

async function fetchRemoteNotifications() {
  const res = await fetch(NOTIFICATIONS_URL + "?t=" + Date.now(), { cache: "no-store" });
  if (!res.ok) throw new Error("Notifications fetch failed: " + res.status);
  const data = await res.json();
  return Array.isArray(data.notifications) ? data.notifications : [];
}

async function fetchLocalNotifications() {
  try {
    const res = await fetch(browser.runtime.getURL("notifications.json"), { cache: "no-store" });
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data.notifications) ? data.notifications : [];
  } catch (e) {
    return [];
  }
}

async function checkForUpdates() {
  try {
    const localVersion = getLocalVersion();
    const remote = await fetchRemoteManifest();
    const remoteVersion = remote.version;
    const hasUpdate = isNewerVersion(remoteVersion, localVersion);

    const md = await fetchChangelog();
    const entries = parseChangelog(md);

    const localIdx = entries.findIndex(e => e.version === localVersion);
    const visibleEntries = hasUpdate
      ? entries.slice(0, Math.max(localIdx, 0) + 1).filter(e => isNewerVersion(e.version, localVersion) || e.version === remoteVersion)
      : entries.slice(0, 3);

    // Загружаем уведомления с GitHub, с fallback на локальный файл
    let notifications = [];
    try {
      notifications = await fetchRemoteNotifications();
    } catch (e) {
      console.warn("Remote notifications failed, using local:", e);
      notifications = await fetchLocalNotifications();
    }

    const state = {
      lastCheck: Date.now(),
      localVersion,
      remoteVersion,
      hasUpdate,
      downloadUrl: null,
      changelogEntries: visibleEntries,
      notifications,
      error: null
    };

    await browser.storage.local.set({ updateState: state });

    if (hasUpdate) {
      browser.action.setBadgeText({ text: "NEW" });
      browser.action.setBadgeBackgroundColor({ color: "#ff0000" });
    } else {
      browser.action.setBadgeText({ text: "" });
    }

    return state;
  } catch (err) {
    // Даже при ошибке обновления пробуем отдать локальные уведомления
    const localNotifications = await fetchLocalNotifications();

    const state = {
      lastCheck: Date.now(),
      localVersion: getLocalVersion(),
      remoteVersion: null,
      hasUpdate: false,
      downloadUrl: null,
      changelogEntries: [],
      changelogError: err.message,
      notifications: localNotifications,
      error: err.message
    };
    await browser.storage.local.set({ updateState: state });
    return state;
  }
}
