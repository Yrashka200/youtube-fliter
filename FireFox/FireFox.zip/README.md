# YouTube Feed Filter for Firefox

This folder is a standalone Firefox Manifest V3 version of YouTube Feed Filter.
The Chrome version in the repository root is unchanged.
It supports Firefox 140+ on desktop and Firefox 142+ on Android.

## Upload to Firefox Add-ons (AMO / DevHub)

1. Select the **contents** of this `FireFox` folder (not the folder itself).
2. Create a ZIP archive with `manifest.json` at the archive root.
3. Upload that ZIP as a new add-on at <https://addons.mozilla.org/developers/>.

Firefox delivers signed add-on updates through AMO. Keep the Gecko extension ID
in `manifest.json` unchanged for future releases.

The extension stores settings and watch-time statistics in browser storage and
does not transmit them. Its update checker only downloads the public version
manifest, changelog, and notification feed.
